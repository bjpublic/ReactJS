import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

const UserInfo = {
    Name: function (props) {
        return <h1>저의 이름은 {props.name}</h1>;
    },
    Jab: function (props) {
        return <h1>저의 직업은 {props.jab}</h1>;
    }
}

ReactDOM.render(
    <div>
        <UserInfo.Name name="beomy" />
        <UserInfo.Jab jab="programer" />
    </div>,
    document.getElementById('root')
);
