import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function PrevendEvent() {
    function handleClick(e) {
      console.log('a 태그 클릭');
      return false;
    }
  
    return (
      <a href="http://beomy.tistory.com/" onClick={handleClick} target="_blank">기본 동작 막기</a>
    );
  }
  
  ReactDOM.render(
      <PrevendEvent />,
      document.getElementById('root')
  )