﻿create-react-app을 이용하여 프로젝트를 생성하였습낟.
Node.JS(https://nodejs.org/ko/) 설치 후 해당 예제 경로에서
1. npm install 로 package를 설치합니다.
2. npm start 로 코드를 실행합니다.