import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function UserInfo(props) {
    return (
        <h1>{props.data.jab}, {props.data.name} 입니다.</h1>
    );
}
let userData = {
    name: "beomy",
    jab: "programmer"
}
ReactDOM.render(
    <UserInfo data={userData} />,
    document.getElementById('root')
);