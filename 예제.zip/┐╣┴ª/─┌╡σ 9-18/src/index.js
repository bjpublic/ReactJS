import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function NumberList(props) {
    const numbers = props.numbers;
    const listItems = numbers.map((number) =>
        <li key={number.toString()}>{number}</li>
    );
    const squareListItems = numbers.map((number) =>
        <li key={number.toString()}>{number*number}</li>
    );
    return (
        <div>
            <ul>
                {listItems}
            </ul>
            <ul>
                {squareListItems}
            </ul>
        </div>
    );
}
 
const numbers = [1, 2, 3, 4, 5];
ReactDOM.render(
    <NumberList numbers={numbers} />,
    document.getElementById('root')
);