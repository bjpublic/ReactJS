import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class SelectControlled extends React.Component {
    constructor(props) {
        super(props);
        this.state = {value: 'second'};

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleChange(event) {
        this.setState({value: event.target.value});
    }

    handleSubmit(event) {
        alert(this.state.value);
        event.preventDefault();
    }

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                <select value={this.state.value} onChange={this.handleChange}>
                  <option value="first">첫번째</option>
                  <option value="second">두번째</option>
                  <option value="third">세번째</option>
                </select>
                <input type="submit" value="Submit" />
            </form>
        );
    }
}

ReactDOM.render(
    <SelectControlled />,
    document.getElementById('root')
);