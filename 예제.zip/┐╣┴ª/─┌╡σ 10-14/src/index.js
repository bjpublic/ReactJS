import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class MultiControlled extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            text: '',
            textarea: '',
            select: 'second'
        };

        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }
  
    handleSubmit(event) {
        alert(this.state.text + ', ' + this.state.textarea + ', ' + this.state.select);
        event.preventDefault();
    }
  
    handleChange(event) {
        const target = event.target;
        const name = target.name;

        this.setState({
            [name]: value
        });
    }

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                <input name="text" type="text" value={this.state.text} onChange={this.handleChange} /><br />
                <textarea name="textarea" value={this.state.textarea} onChange={this.handleChange} /><br />
                <select name="select" value={this.state.select} onChange={this.handleChange}><br />
                  <option value="first">첫번째</option>
                  <option value="second">두번째</option>
                  <option value="third">세번째</option>
                </select><br />
                <input type="submit" value="Submit" />
            </form>
        );
    }
}

ReactDOM.render(
    <MultiControlled />,
    document.getElementById('root')
);