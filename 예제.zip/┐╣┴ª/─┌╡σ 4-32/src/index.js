import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function ArrayChildren(props) {
    return <h3>{JSON.stringify(props.children)}</h3>;
}

ReactDOM.render(
    <ArrayChildren>
        <h1>h1</h1>
        <h2>h2</h2>
    </ArrayChildren>,
    document.getElementById('root')
);