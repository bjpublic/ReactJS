import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function NumberType(props) {
    return (
        <h1>
            {props.number % 2 == 0
              ? props.number + "는(은) 짝수입니다."
              : props.number + "는(은) 홀수입니다."}
        </h1>
    );
}

ReactDOM.render(
    <div>
        <NumberType number="2" />
        <NumberType number="3" />
    </div>,
    document.getElementById('root')
);