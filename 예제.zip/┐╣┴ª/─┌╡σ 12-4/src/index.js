import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function Title(props) {
    return (<i>{props.title}</i>);
}

function Contents(props) {
    return (<i>{props.contents}</i>);  
}

class Dialog extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <h1>{this.props.title}</h1>
                <div>{this.props.contents}</div>
                {this.props.children}
            </div>
        );
    }
}

ReactDOM.render(
    <Dialog
        title={
            <Title title="TITLE" />
        }
        contents={
            <Contents contents="CONTENTS" />
        }>
        <button>버튼</button>
    </Dialog>,
    document.getElementById('root')
);