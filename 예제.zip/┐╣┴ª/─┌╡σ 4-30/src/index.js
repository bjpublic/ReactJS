import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function StringChildren(props) {
    return <h3>{JSON.stringify(props.children)}</h3>;
}

ReactDOM.render(
    <StringChildren>문자열입니다.</StringChildren>,
    document.getElementById('root')
);