import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class InputUncontrolled extends React.Component {
    constructor(props) {
        super(props);
        this.handleSubmit = this.handleSubmit.bind(this);
    }

    handleSubmit(event) {
        alert(this.input.value);
        event.preventDefault();
    }

    render() {
        return (
            <form onSubmit={this.handleSubmit}>
                <input type="text" defaultValue="기본값입니다." ref={(input) => this.input = input} />
                <input type="submit" value="Submit" />
            </form>
        );
    }
}

ReactDOM.render(
    <InputUncontrolled />,
    document.getElementById('root')
);