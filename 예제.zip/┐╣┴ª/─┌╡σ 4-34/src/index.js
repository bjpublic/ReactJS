import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class UserInfo extends React.Component {
    render() {
        return (
            <div>
                <h1>제 이름은 {this.props.name} 입니다.</h1>
                <h1>제 직업은 {this.props.jab} 입니다.</h1>
            </div>
        );
    }
}

UserInfo.defaultProps = {
  jab: 'programer'
}

ReactDOM.render(
    <UserInfo name="beomy" />,
    document.getElementById('root')
);
