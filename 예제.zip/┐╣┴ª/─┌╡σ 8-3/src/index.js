import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function Title(props) {
    return (
        <h1>{props.title}</h1>
    );
}

function Time24H(props) {
    let time = props.time;
    return (
        <h2>{`${time.getHours()}:${time.getMinutes()}:${time.getSeconds()}`}</h2>
    );
}

function Time12H(props) {
    let time = props.time;
    return ( 
        <h2>{`${time.getHours() != 12 ? time.getHours()%12 : 12}:${time.getMinutes()}:${time.getSeconds()}`}</h2>
    );  
}

function Time(props) {
    if (props.is12h) {
        return <Time12H time={props.time} />;
    } else {
        return <Time24H time={props.time} />;
    }
}

class Clock extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            time: new Date(),
            is12h: true
        };
        this.alarmHandler = this.alarmHandler.bind(this);
        this.timeTypeHandler = this.timeTypeHandler.bind(this);
    }
  
    tick() {
        this.setState({
            time: new Date()
        });
    }
  
    componentDidMount() {
        this.timerID = setInterval(
            () => this.tick(),
            1000
        );
    }
  
    componentWillUnmount() {
        clearInterval(this.timerID);
    }
  
    alarmHandler(e) {
        setTimeout(() => {
            alert('현재 시간 : ' + this.state.time.toLocaleTimeString())
        }, 300000);
        alert('5분 후 알람이 울립니다.');
    }

    timeTypeHandler(e) {
        this.setState({
            is12h: e.target.value === 'true' ? true : false
        });
    }
  
    render() {
        return (
            <div>
                <Title title={this.props.title} />
                <label><input type="radio" name="timeType" value="true" onChange={this.timeTypeHandler} checked={this.state.is12h} />12시간제</label>
                <label><input type="radio" name="timeType" value="false" onChange={this.timeTypeHandler} checked={!this.state.is12h} />24시간제</label>
                <Time time={this.state.time} is12h={this.state.is12h} />
                <button onClick={this.alarmHandler}>5분 후 알람</button>
            </div>
        );
    }
}

ReactDOM.render(
    <Clock title="React.JS Clock" />,
    document.getElementById('root')
);