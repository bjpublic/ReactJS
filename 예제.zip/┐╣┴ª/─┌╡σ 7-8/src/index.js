import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class EventComponent extends React.Component {
  eventHandler(e) {
      console.log('이벤트 핸들러 입니다.', this);
  }

  render() {
      return (
          <button onClick={this.eventHandler}>Event Handler</button>
      );
  }
}

ReactDOM.render(
  <EventComponent />,
  document.getElementById('root')
)
