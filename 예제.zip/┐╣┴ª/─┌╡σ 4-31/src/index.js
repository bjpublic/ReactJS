import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function ObjectChildren(props) {
    return <h3>{JSON.stringify(props.children)}</h3>;
}

ReactDOM.render(
    <ObjectChildren>
        <h1>h1</h1>
    </ObjectChildren>,
    document.getElementById('root')
);