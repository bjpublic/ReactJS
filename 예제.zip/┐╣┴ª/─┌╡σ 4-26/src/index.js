import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function Square(props) {
    return (
        <h1>{props.number} squire is {props.number * props.number}</h1>
    );
}

ReactDOM.render(
    <Square number="2" />,
    document.getElementById('root')
);