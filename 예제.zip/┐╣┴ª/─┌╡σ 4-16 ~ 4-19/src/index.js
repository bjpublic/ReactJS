import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function PostTitle(props) {
    return (
        <div className="postTitle">
            <div className="title">
                <h1>제목 : {props.title}</h1>
            </div>
            <div className="subTitle">
                <h2>부제 : {props.subTitle}</h2>
            </div>
        </div>
    );
}

function PostDate(props) {
    return (
        <div className="postDate">
            <div className="createDate">
                <p>최초 생성 날짜 : {props.createDate}</p>
            </div>
            <div className="modifyDate">
                <p>마지막 수정 날짜 : {props.modifyDate}</p>
            </div>
        </div>
    );
}

function PostContents(props) {
    return (
        <div className="postContents">
            {props.contents}
        </div>
    );
}

function Post(props) {
    return (
        <div className="post">
            <PostTitle title={props.title} subTitle={props.subTitle} />
            <PostDate createDate={props.createDate} modifyDate={props.modifyDate} />
            <PostContents contents={props.contents} />
        </div>
    );
}

ReactDOM.render(
    <Post title="React.JS"
      subTitle="Components"
      createDate="0000-00-00"
      modifyDate="1111-11-11"
      contents="React.JS의 Components에 관련된 포스팅입니다." />,
    document.getElementById('root')
);
