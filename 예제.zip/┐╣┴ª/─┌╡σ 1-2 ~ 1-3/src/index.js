import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

ReactDOM.render(
  <h1>간단한 컴포넌트 예제</h1>,
  document.getElementById('root')
);