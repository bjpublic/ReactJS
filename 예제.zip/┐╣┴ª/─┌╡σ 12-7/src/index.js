import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class Dialog extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <h1>{this.props.title}</h1>
                <div>{this.props.contents}</div>
                {this.props.children}
            </div>
        );
    }
}

class ConfirmDialog extends React.Component {
    constructor(props) {
        super(props);
        this.handleCancel = this.handleCancel.bind(this);
        this.handleConfirm = this.handleConfirm.bind(this);
    }

    handleCancel(event) {
        alert("Confirm CANCEL");
    }

    handleConfirm(event) {
        alert("Confirm OKAY");
    }

    render() {
        return (
            <Dialog
                title={this.props.title}
                contents={this.props.contents}>
                <button onClick={this.handleCancel}>취소</button>
                <button onClick={this.handleConfirm}>확인</button>
            </Dialog>
        );
    }
}

class AlertDialog extends React.Component {
    constructor(props) {
        super(props);
        this.handleCancel = this.handleCancel.bind(this);
    }

    handleCancel(event) {
        alert("Alert CANCEL");
    }

    render() {
        return (
            <Dialog
                title={this.props.title}
                contents={this.props.contents}>
                <button onClick={this.handleCancel}>취소</button>
            </Dialog>
        );
    }
}

class DialogGroup extends React.Component {
    render() {
        let type = this.props.type;
        let title = this.props.title;
        let contents = this.props.contents;
        let dialog = null;
      
        if (type === 'confirm') {
            dialog = (
                <ConfirmDialog
                  title={title}
                  contents={contents}>
                </ConfirmDialog>
            );
        } else {
            dialog = (
                <AlertDialog
                  title={title}
                  contents={contents}>
                </AlertDialog>
            );
        }
      
        return dialog;
    }
}

ReactDOM.render(
    <DialogGroup type="confirm" title="TITLE" contents="CONTENTS" />,
    document.getElementById('root')
);