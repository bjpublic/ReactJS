import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function UndefinedChildren(props) {
    return <h3>{props.children === undefined ? "undefined" : JSON.stringify(props.children)}</h3>;
}

ReactDOM.render(
    <UndefinedChildren />,
    document.getElementById('root')
);