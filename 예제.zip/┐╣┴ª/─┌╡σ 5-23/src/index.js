import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class TestComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = { quantity: 1 };
    }
  
    componentDidMount() {
        this.setState({
            quantity: this.state.quantity + 1
        });
        this.setState({
            quantity: this.state.quantity + 1
        });
    }
  
    render() {
        return (
            <div>quantity : {this.state.quantity}</div>
        );
    }
}

ReactDOM.render(
    <TestComponent number="2" />,
    document.getElementById('root')
);