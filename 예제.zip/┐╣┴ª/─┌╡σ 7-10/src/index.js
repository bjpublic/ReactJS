import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function Title(props) {
    return (
        <h1>{props.title}</h1>
    );
}

function Time(props) {
    return (
        <h2>{props.time.toLocaleTimeString()}</h2>
    );
}

class Clock extends React.Component {
    constructor(props) {
        super(props);
        this.state = { time: new Date() };
        this.alarmHandler = this.alarmHandler.bind(this);
    }
  
    tick() {
        this.setState({
            time: new Date()
        });
    }
  
    componentDidMount() {
        this.timerID = setInterval(
            () => this.tick(),
            1000
        );
    }
  
    componentWillUnmount() {
        clearInterval(this.timerID);
    }
  
    alarmHandler(e) {
        setTimeout(() => {
            alert('현재 시간 : ' + this.state.time.toLocaleTimeString())
        }, 300000);
        alert('5분 후 알람이 울립니다.');
    }
  
    render() {
        return (
            <div>
                <Title title={this.props.title} />
                <Time time={this.state.time} />
                <button onClick={this.alarmHandler}>5분 후 알람</button>
            </div>
        );
    }
}

ReactDOM.render(
    <Clock title="React.JS Clock" />,
    document.getElementById('root')
);