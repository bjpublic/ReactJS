import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class Dialog extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <h1>{this.props.title}</h1>
                <div>{this.props.contents}</div>
                {this.props.children}
            </div>
        );
    }
}

class AlertDialog extends React.Component {
    constructor(props) {
        super(props);
        this.handleCancel = this.handleCancel.bind(this);
    }

    handleCancel(event) {
        alert("Alert CANCEL");
    }

    render() {
        return (
            <Dialog
                title={this.props.title}
                contents={this.props.contents}>
                <button onClick={this.handleCancel}>취소</button>
            </Dialog>
        );
    }
}

ReactDOM.render(
    <AlertDialog
        title="TITLE"
        contents="CONTENTS">
    </AlertDialog>,
    document.getElementById('root')
);