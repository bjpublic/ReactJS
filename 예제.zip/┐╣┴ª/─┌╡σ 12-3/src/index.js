import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class Dialog extends React.Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <h1>{this.props.title}</h1>
                <div>{this.props.contents}</div>
                {this.props.children}
            </div>
        );
    }
}

ReactDOM.render(
    <Dialog
        title="TITLE"
        contents="CONTENTS">
        <button>버튼</button>
    </Dialog>,
    document.getElementById('root')
);