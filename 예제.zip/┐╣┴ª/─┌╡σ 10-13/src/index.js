import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function Title(props) {
    return (
        <h1>{props.title}</h1>
    );
}

function Time24H(props) {
    let time = props.time;
    return (
        <h2>{`${time.getHours()}:${time.getMinutes()}:${time.getSeconds()}`}</h2>
    );
}

function Time12H(props) {
    let time = props.time;
    return ( 
        <h2>{`${time.getHours() != 12 ? time.getHours()%12 : 12}:${time.getMinutes()}:${time.getSeconds()}`}</h2>
    );  
}

function Time(props) {
    if (props.is12h) {
        return <Time12H time={props.time} />;
    } else {
        return <Time24H time={props.time} />;
    }
}

function AlarmInfo (props) {
    if (props.alarmList.length === 0) {
        return null;
    }
    return (
        <p>총 {props.alarmList.length}개 알람이 등록 되었습니다.</p>
    );
}

function AlarmList (props) {
    const alarmList = props.alarmList;
    const li = alarmList.map((alarm) => {
        return (<li key={alarm.timerID}>{alarm.timerID} : {alarm.time.toLocaleTimeString()}</li>);
    });
    return (
        <ul>{li}</ul>
    )
}

class Clock extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            time: new Date(),
            is12h: true,
            alarmList: [],
            alarmTime: 5,
            alarmText: '',
            isInput: false
        };
        this.alarmHandler = this.alarmHandler.bind(this);
        this.timeTypeHandler = this.timeTypeHandler.bind(this);
        this.alarmTimeHandler = this.alarmTimeHandler.bind(this);
        this.alarmTextHandler = this.alarmTextHandler.bind(this);
        this.selectAlramHandler = this.selectAlramHandler.bind(this);
        this.alarmSelectHandler = this.alarmSelectHandler.bind(this);
    }
  
    tick() {
        this.setState({
            time: new Date()
        });
    }
  
    componentDidMount() {
        this.timerID = setInterval(
            () => this.tick(),
            1000
        );
    }
  
    componentWillUnmount() {
        clearInterval(this.timerID);
    }
  
    alarmHandler(e) {
        let timerID = setTimeout(() => {
            this.setState((prevState, props) => {
                let alarmList = prevState.alarmList.slice();
                let spliceIndex = 0;
                for (let item of alarmList) {
                    if (item['timerID'] === timerID) {
                        spliceIndex = alarmList.indexOf(item);
                        alert(item.text);
                    }
                }
                alarmList.splice(spliceIndex, 1);
                return {alarmList: alarmList};
            });
        }, this.state.alarmTime * 60 * 1000);
        this.setState((prevState, props) => {
            let alarmList = prevState.alarmList.slice();
            var alarmTime = new Date();
            alarmTime.setMinutes(alarmTime.getMinutes() + prevState.alarmTime);
            alarmList.push({
                timerID: timerID,
                time: alarmTime,
                text: prevState.alarmText
            });
            return {alarmList: alarmList};
        });
    }

    timeTypeHandler(e) {
        this.setState({
            is12h: e.target.value === 'true' ? true : false
        });
    }
  
    alarmTimeHandler(e) {
        this.setState({
            alarmTime: Number(e.target.value.replace(/[^0-9]/g, ''))
        });
    }
  
    alarmTextHandler(e) {
        this.setState({
            alarmText: e.target.value
        });
    }
  
    selectAlramHandler(e) {
        this.setState({
            isInput: e.target.value === 'true'
        });
    }
  
    alarmSelectHandler(e) {
        this.setState({
            alarmTime: Number(e.target.value.replace(/[^0-9]/g, ''))
        });
    }
  
    render() {
        return (
            <div>
                <Title title={this.props.title} />
                <label><input type="radio" name="timeType" value="true" onChange={this.timeTypeHandler} checked={this.state.is12h} />12시간제</label>
                <label><input type="radio" name="timeType" value="false" onChange={this.timeTypeHandler} checked={!this.state.is12h} />24시간제</label>
                <Time time={this.state.time} is12h={this.state.is12h} />
                <label><input type="radio" name="selectAlarm" value="true" onChange={this.selectAlramHandler} checked={this.state.isInput} />input</label>
                <label><input type="radio" name="selectAlarm" value="false" onChange={this.selectAlramHandler} checked={!this.state.isInput} />select</label>
                <br />
                {this.state.isInput ?
                    <input type="number" onChange={this.alarmTimeHandler} value={this.state.alarmTime} /> :
                    <select value={this.state.alarmTime} onChange={this.alarmSelectHandler}>
                        <option value="5">5분 후</option >
                        <option value="10">10분 후</option >
                        <option value="15">15분 후</option >
                    </select>
                }
                <br />
                <textarea onChange={this.alarmTextHandler} value={this.state.alarmText} /><br />
                <button onClick={this.alarmHandler}>알람 등록</button>
                <AlarmInfo alarmList={this.state.alarmList} />
                <AlarmList alarmList={this.state.alarmList} />
            </div>
        );
    }
}

ReactDOM.render(
    <Clock title="React.JS Clock" />,
    document.getElementById('root')
);