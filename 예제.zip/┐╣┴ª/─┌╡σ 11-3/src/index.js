import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function TextLength(props) {
    return <p>Text lenght : {props.text.length}</p>
}

class TextInput extends React.Component {
    constructor(props) {
        super(props);
        this.state = { text:"" };
        this.handleChange = this.handleChange.bind(this);
    }
  
    handleChange(event) {
        this.setState({ text: event.target.value });
    }
  
    render() {
        var textCase = this.props.textCase;
        var text = this.state.text;
        return (
            <fieldset>
                <legend>{textCase} Area</legend>
                <input value={text} onChange={this.handleChange} />
                <TextLength text={text} />
            </fieldset>
        )
    }
}

class TextGroup extends React.Component {
    render() {
        return (
            <div>
                <TextInput textCase="lower" />
                <TextInput textCase="upper" />
            </div>
        );
    }
}

ReactDOM.render(
    <TextGroup />,
    document.getElementById('root')
);