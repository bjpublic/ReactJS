import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class TestComponent extends React.Component {
    constructor(props) {
        super(props);
        this.state = { type: '' };
    }
  
    componentDidMount() {
        this.setState({
            type: 'test'
        });
        if (this.state.type === 'test') {
            console.log('state 업데이트가 적용되었습니다.')
        } else {
            console.log('this.state.type이 test가 되는 것을 보장할 수 없습니다.');
        }
    }
  
    render() {
        return (
            <div>TEST</div>
        );
    }
}

ReactDOM.render(
    <TestComponent />,
    document.getElementById('root')
);