import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

let style = {
  color: 'white',
  backgroundColor: 'black'
}

const element = (
  <div>
      <h1>Hello!</h1>
      <h2 style={style}>React.JS</h2>
  </div>
);

ReactDOM.render(
  element,
  document.getElementById('root')
);