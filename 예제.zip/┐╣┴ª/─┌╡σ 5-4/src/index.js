import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function Title(props) {
    return (
        <h1>{props.title}</h1>
    );
}

function Time(props) {
    return (
        <h2>{props.time.toLocaleTimeString()}</h2>
    );
}

class Clock extends React.Component {
    render() {
        return (
            <div>
                <Title title={this.props.title} />
                <Time time={this.props.time} />
            </div>
        );
    }
}

function tick() {
    ReactDOM.render(
        <Clock title="React.JS Clock" time={new Date()} />,
        document.getElementById('root')
    );
}

setInterval(tick, 1000);