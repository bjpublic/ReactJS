import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function toUpperText(text) {
    return text.toUpperCase();
}

function toLowerText(text) {
    return text.toLowerCase();
}

function TextLength(props) {
    return <p>Text lenght : {props.text.length}</p>
}

class TextInput extends React.Component {
    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
    }
  
    handleChange(event) {
        this.props.onTextChange(event.target.value);
    }
  
    render() {
        var textCase = this.props.textCase;
        var text = this.props.text;
    
        return (
            <fieldset>
                <legend>{textCase} Area</legend>
                <input value={text} onChange={this.handleChange} />
            </fieldset>
        );
    }
}

class TextGroup extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            textCase: "",
            text: ""
        };
    
        this.handleLower = this.handleLower.bind(this);
        this.handleUpper = this.handleUpper.bind(this);
    }
  
    handleLower(text) {
        this.setState({
            textCase: "lower",
            text: text
        });
    }
  
    handleUpper(text) {
        this.setState({
            textCase: "upper",
            text: text
        });
    }
  
    render() {
        var text = this.state.text;
        var lowerText = toLowerText(text);
        var upperText = toUpperText(text);
    
        return (
            <div>
                <TextInput textCase="lower" text={lowerText} onTextChange={this.handleLower} />
                <TextInput textCase="upper" text={upperText} onTextChange={this.handleUpper} />
                <TextLength text={text} />        
            </div>
        );
    }
}

ReactDOM.render(
    <TextGroup />,
    document.getElementById('root')
);