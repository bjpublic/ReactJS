import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function square(number) {
  return number * number;
}

let number = 2;

const element = <h1>{number} square is {square(number)}!</h1>;

ReactDOM.render(
  element,
  document.getElementById('root')
);