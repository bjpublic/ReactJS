import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function TextLength(props) {
    return <p>Text lenght : {props.text.length}</p>
}

class TextInput extends React.Component {
    constructor(props) {
        super(props);
        this.state = { text:"" };
        this.handleChange = this.handleChange.bind(this);
    }
  
    handleChange(event) {
        this.setState({ text: event.target.value });
    }
  
    render() {
        var text = this.state.text;
        return (
            <fieldset>
                <legend>Enter text:</legend>
                <input value={text} onChange={this.handleChange} />
                <TextLength text={text} />
            </fieldset>
        )
    }
}

ReactDOM.render(
    <TextInput />,
    document.getElementById('root')
);