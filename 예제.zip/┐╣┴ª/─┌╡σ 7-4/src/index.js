import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

function EventComponent() {
    function eventHandler(e) {
        console.log('이벤트 핸들러 입니다.');
    }

    return (
        <button onClick={eventHandler}>Event Handler</button>
    );
}

ReactDOM.render(
    <EventComponent />,
    document.getElementById('root')
)